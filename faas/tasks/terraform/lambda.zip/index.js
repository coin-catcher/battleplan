"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/handler.ts
var handler_exports = {};
__export(handler_exports, {
  createHandler: () => createHandler,
  handler: () => handler
});
module.exports = __toCommonJS(handler_exports);

// ../shared/src/errors.ts
var HttpError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
    this.name = "HttpError";
  }
};

// ../shared/src/ids.ts
var import_node_crypto = require("node:crypto");
function newId() {
  return (0, import_node_crypto.randomUUID)();
}
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
var systemClock = { newId, nowIso };

// ../shared/src/cursor-client.ts
function asRecord(value) {
  return value && typeof value === "object" ? value : {};
}
function mapAgent(value) {
  const record = asRecord(value);
  return {
    id: String(record.id ?? ""),
    name: String(record.name ?? ""),
    status: String(record.status ?? ""),
    url: String(record.url ?? ""),
    latestRunId: typeof record.latestRunId === "string" ? record.latestRunId : void 0
  };
}
function mapRun(value) {
  const record = asRecord(value);
  const git = asRecord(record.git);
  const branches = Array.isArray(git.branches) ? git.branches.map((item) => {
    const branch = asRecord(item);
    return {
      repoUrl: String(branch.repoUrl ?? ""),
      branch: typeof branch.branch === "string" ? branch.branch : void 0,
      prUrl: typeof branch.prUrl === "string" ? branch.prUrl : void 0
    };
  }) : void 0;
  return {
    id: String(record.id ?? ""),
    agentId: String(record.agentId ?? ""),
    status: String(record.status ?? ""),
    result: typeof record.result === "string" ? record.result : void 0,
    git: branches ? { branches } : void 0
  };
}
var HttpCursorClient = class {
  constructor(options) {
    this.options = options;
    this.baseUrl = (options.baseUrl ?? "https://api.cursor.com").replace(/\/$/, "");
    this.fetchImpl = options.fetchImpl ?? fetch;
  }
  baseUrl;
  fetchImpl;
  async createAgent(input) {
    const body = {
      prompt: { text: input.prompt },
      mode: input.mode ?? "agent",
      autoCreatePR: input.autoCreatePr ?? false
    };
    if (input.name) body.name = input.name.slice(0, 100);
    if (input.repoUrl) {
      const repo = { url: input.repoUrl };
      if (input.startingRef) repo.startingRef = input.startingRef;
      if (input.prUrl) repo.prUrl = input.prUrl;
      body.repos = [repo];
    }
    const payload = await this.request("POST", "/v1/agents", body);
    return { agent: mapAgent(payload.agent), run: mapRun(payload.run) };
  }
  async getAgent(agentId) {
    return mapAgent(await this.request("GET", `/v1/agents/${encodeURIComponent(agentId)}`));
  }
  async archiveAgent(agentId) {
    await this.request("POST", `/v1/agents/${encodeURIComponent(agentId)}/archive`);
  }
  async createRun(agentId, input) {
    const body = { prompt: { text: input.text } };
    if (input.mode) body.mode = input.mode;
    const payload = await this.request(
      "POST",
      `/v1/agents/${encodeURIComponent(agentId)}/runs`,
      body
    );
    return mapRun(payload.run ?? payload);
  }
  async listRuns(agentId) {
    const payload = await this.request(
      "GET",
      `/v1/agents/${encodeURIComponent(agentId)}/runs?limit=20`
    );
    const items = Array.isArray(payload.items) ? payload.items : [];
    return items.map((item) => mapRun(item));
  }
  async getRun(agentId, runId) {
    return mapRun(
      await this.request(
        "GET",
        `/v1/agents/${encodeURIComponent(agentId)}/runs/${encodeURIComponent(runId)}`
      )
    );
  }
  async cancelRun(agentId, runId) {
    await this.request(
      "POST",
      `/v1/agents/${encodeURIComponent(agentId)}/runs/${encodeURIComponent(runId)}/cancel`
    );
  }
  async listArtifacts(agentId) {
    const payload = await this.request(
      "GET",
      `/v1/agents/${encodeURIComponent(agentId)}/artifacts`
    );
    const items = Array.isArray(payload.items) ? payload.items : [];
    return items.map((item) => {
      const record = asRecord(item);
      return {
        path: String(record.path ?? ""),
        sizeBytes: Number(record.sizeBytes ?? 0),
        updatedAt: String(record.updatedAt ?? "")
      };
    }).filter((item) => item.path.startsWith("artifacts/"));
  }
  async downloadArtifact(agentId, path) {
    const payload = await this.request(
      "GET",
      `/v1/agents/${encodeURIComponent(agentId)}/artifacts/download?path=${encodeURIComponent(path)}`
    );
    return {
      url: String(payload.url ?? ""),
      expiresAt: String(payload.expiresAt ?? "")
    };
  }
  async request(method, path, body) {
    if (!this.options.apiKey) {
      throw new HttpError(500, "CURSOR_API_KEY is not configured.");
    }
    const response = await this.fetchImpl(`${this.baseUrl}${path}`, {
      method,
      headers: {
        authorization: `Basic ${Buffer.from(`${this.options.apiKey}:`).toString("base64")}`,
        accept: "application/json",
        ...body === void 0 ? {} : { "content-type": "application/json" }
      },
      body: body === void 0 ? void 0 : JSON.stringify(body)
    });
    const text = await response.text();
    let parsed = {};
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = { message: text };
      }
    }
    if (!response.ok) {
      const record = asRecord(parsed);
      const message = typeof record.message === "string" && record.message ? record.message : text || response.statusText;
      const status = response.status === 409 ? 409 : 502;
      throw new HttpError(status, `Cursor API error: ${message}`);
    }
    return parsed;
  }
};

// ../shared/src/domain.ts
var TASK_STATUSES = ["TODO", "DOING", "REVIEW", "DONE", "ABANDONED"];
function isTaskStatus(value) {
  return typeof value === "string" && TASK_STATUSES.includes(value);
}
function isOutputType(value) {
  return value === "code" || value === "research";
}
function researchPath(projectId, taskId) {
  return `research/${projectId}/${taskId}/`;
}

// ../shared/src/prompts.ts
var GENERATE_TASKS_INSTRUCTION = [
  "Generate an ordered list of project tasks based on the agreed decisions in this warplan.",
  "Return only a JSON array, with no markdown and no commentary.",
  "Each item must be an object with:",
  '- "title": string, a short task name',
  '- "prompt": string, the instruction the executing agent should follow',
  '- "output_type": "code" or "research"',
  '- "depends_on": array of task titles this task depends on',
  "A task must declare exactly one output type. If work needs both research and code, emit two tasks.",
  "Order the array so each task appears after the tasks it depends on."
].join("\n");
function taskExecutionPrompt(task, project) {
  const lines = [`You are executing a warplan ${task.output_type} task.`];
  if (task.output_type === "research") {
    lines.push(
      `Write the research into the git repository under \`${researchPath(project.project_id, task.task_id)}\`.`,
      "Use markdown, JSON, CSV, or YAML, whichever fits the findings.",
      "Do not change application source code.",
      "Open a pull request that contains those research files."
    );
  } else {
    lines.push("Implement the task in code and open a pull request.");
  }
  lines.push(`Task title: ${task.title}`, `Task prompt:
${task.prompt}`);
  if (task.dependencies.length > 0) {
    lines.push(`This task depends on these completed task ids: ${task.dependencies.join(", ")}.`);
  }
  return lines.join("\n\n");
}

// ../shared/src/status.ts
var GUIDED = {
  TODO: ["DOING", "ABANDONED"],
  DOING: ["REVIEW", "DONE", "ABANDONED"],
  REVIEW: ["DOING", "DONE", "ABANDONED"],
  DONE: [],
  ABANDONED: []
};
function assertCanTransition(from, to, manual) {
  if (!isTaskStatus(to)) {
    throw new HttpError(400, "Unknown task status.");
  }
  if (from === to) return;
  if (manual) return;
  if (!GUIDED[from].includes(to)) {
    throw new HttpError(
      400,
      `Cannot move a task from ${from} to ${to}. Expected one of: ${GUIDED[from].join(", ") || "a manual change"}.`
    );
  }
}

// ../shared/src/dynamo-repository.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var INTERNAL = /* @__PURE__ */ new Set(["pk", "sk", "entity", "gsi1pk", "gsi1sk", "gsi2pk", "gsi2sk"]);
function strip(item) {
  const copy = {};
  for (const [key, value] of Object.entries(item)) {
    if (!INTERNAL.has(key) && value !== void 0) copy[key] = value;
  }
  return copy;
}
var DynamoRepository = class {
  constructor(tableName, client = new import_client_dynamodb.DynamoDBClient({})) {
    this.tableName = tableName;
    this.documents = import_lib_dynamodb.DynamoDBDocumentClient.from(client, {
      marshallOptions: { removeUndefinedValues: true }
    });
  }
  documents;
  async saveProject(project) {
    await this.documents.send(new import_lib_dynamodb.PutCommand({
      TableName: this.tableName,
      Item: {
        ...project,
        pk: `PROJECT#${project.project_id}`,
        sk: "META",
        entity: "project",
        gsi1pk: "PROJECT",
        gsi1sk: `${project.updated_at}#${project.project_id}`,
        ...project.cursor_agent_id ? { gsi2pk: `AGENT#${project.cursor_agent_id}`, gsi2sk: `PROJECT#${project.project_id}` } : {}
      }
    }));
  }
  async getProject(projectId) {
    const result = await this.documents.send(new import_lib_dynamodb.GetCommand({
      TableName: this.tableName,
      Key: { pk: `PROJECT#${projectId}`, sk: "META" }
    }));
    return result.Item ? strip(result.Item) : null;
  }
  async listProjects() {
    const items = await this.queryIndex("gsi1", "gsi1pk", "PROJECT", false);
    return items.map((item) => strip(item));
  }
  async findProjectByAgent(agentId) {
    const items = await this.queryIndex("gsi2", "gsi2pk", `AGENT#${agentId}`, true);
    const item = items.find((candidate) => candidate.entity === "project");
    return item ? strip(item) : null;
  }
  async deleteProject(projectId) {
    const tasks = await this.listTasks(projectId);
    const keys = (await this.queryPartition(`PROJECT#${projectId}`)).map((item) => ({
      pk: item.pk,
      sk: item.sk
    }));
    for (const task of tasks) {
      const taskItems = await this.queryPartition(`TASK#${task.task_id}`);
      keys.push(...taskItems.map((item) => ({ pk: item.pk, sk: item.sk })));
    }
    await this.deleteKeys(keys);
  }
  async saveTask(task) {
    await this.documents.send(new import_lib_dynamodb.PutCommand({
      TableName: this.tableName,
      Item: {
        ...task,
        pk: `PROJECT#${task.project_id}`,
        sk: `TASK#${task.task_id}`,
        entity: "task",
        gsi2pk: `TASK#${task.task_id}`,
        gsi2sk: "META",
        ...task.cursor_agent_id ? { gsi1pk: `AGENT#${task.cursor_agent_id}`, gsi1sk: `TASK#${task.task_id}` } : {}
      }
    }));
  }
  async saveTasks(tasks) {
    for (const task of tasks) {
      await this.saveTask(task);
    }
  }
  async getTask(taskId) {
    const items = await this.queryIndex("gsi2", "gsi2pk", `TASK#${taskId}`, true);
    const item = items.find((candidate) => candidate.entity === "task");
    return item ? strip(item) : null;
  }
  async listTasks(projectId) {
    const items = await this.queryPartition(`PROJECT#${projectId}`, "TASK#");
    return items.map((item) => strip(item)).sort((left, right) => left.order - right.order || left.created_at.localeCompare(right.created_at));
  }
  async findTaskByAgent(agentId) {
    const items = await this.queryIndex("gsi1", "gsi1pk", `AGENT#${agentId}`, true);
    const item = items.find((candidate) => candidate.entity === "task");
    return item ? strip(item) : null;
  }
  async deleteTask(taskId) {
    const task = await this.getTask(taskId);
    if (!task) return;
    const keys = [
      { pk: `PROJECT#${task.project_id}`, sk: `TASK#${taskId}` },
      ...(await this.queryPartition(`TASK#${taskId}`)).map((item) => ({ pk: item.pk, sk: item.sk }))
    ];
    await this.deleteKeys(keys);
    const siblings = await this.listTasks(task.project_id);
    for (const sibling of siblings) {
      if (!sibling.dependencies.includes(taskId)) continue;
      sibling.dependencies = sibling.dependencies.filter((dependency) => dependency !== taskId);
      await this.saveTask(sibling);
    }
  }
  async getCodeOutput(taskId) {
    return this.getOutput(taskId, "OUTPUT#code");
  }
  async saveCodeOutput(output) {
    await this.putOutput(output.task_id, "OUTPUT#code", "task_code_output", output);
  }
  async getResearchOutput(taskId) {
    return this.getOutput(taskId, "OUTPUT#research");
  }
  async saveResearchOutput(output) {
    await this.putOutput(output.task_id, "OUTPUT#research", "task_research_output", output);
  }
  async listProjectMessages(projectId) {
    const items = await this.queryPartition(`PROJECT#${projectId}`, "MSG#");
    return items.map((item) => strip(item));
  }
  async listTaskMessages(taskId) {
    const items = await this.queryPartition(`TASK#${taskId}`, "MSG#");
    return items.map((item) => strip(item));
  }
  async listArtifacts(scope, ownerId) {
    const pk = scope === "project" ? `PROJECT#${ownerId}` : `TASK#${ownerId}`;
    const items = await this.queryPartition(pk, "ARTIFACT#");
    return items.map((item) => strip(item)).sort((left, right) => left.path.localeCompare(right.path));
  }
  async saveArtifact(artifact) {
    const pk = artifact.scope === "project" ? `PROJECT#${artifact.project_id}` : `TASK#${artifact.task_id}`;
    await this.documents.send(new import_lib_dynamodb.PutCommand({
      TableName: this.tableName,
      Item: {
        ...artifact,
        pk,
        sk: `ARTIFACT#${artifact.path}`,
        entity: "artifact"
      }
    }));
  }
  async saveMessage(message) {
    const pk = message.scope === "project" ? `PROJECT#${message.project_id}` : `TASK#${message.task_id}`;
    await this.documents.send(new import_lib_dynamodb.PutCommand({
      TableName: this.tableName,
      Item: {
        ...message,
        pk,
        sk: `MSG#${message.created_at}#${message.message_id}`,
        entity: "message"
      }
    }));
  }
  async getOutput(taskId, sk) {
    const result = await this.documents.send(new import_lib_dynamodb.GetCommand({
      TableName: this.tableName,
      Key: { pk: `TASK#${taskId}`, sk }
    }));
    return result.Item ? strip(result.Item) : null;
  }
  async putOutput(taskId, sk, entity, output) {
    await this.documents.send(new import_lib_dynamodb.PutCommand({
      TableName: this.tableName,
      Item: { ...output, pk: `TASK#${taskId}`, sk, entity }
    }));
  }
  async queryPartition(pk, skPrefix) {
    const items = [];
    let startKey;
    do {
      const result = await this.documents.send(new import_lib_dynamodb.QueryCommand({
        TableName: this.tableName,
        KeyConditionExpression: skPrefix ? "pk = :pk AND begins_with(sk, :sk)" : "pk = :pk",
        ExpressionAttributeValues: skPrefix ? { ":pk": pk, ":sk": skPrefix } : { ":pk": pk },
        ExclusiveStartKey: startKey
      }));
      items.push(...result.Items ?? []);
      startKey = result.LastEvaluatedKey;
    } while (startKey);
    return items;
  }
  async queryIndex(indexName, keyName, keyValue, forward) {
    const items = [];
    let startKey;
    do {
      const result = await this.documents.send(new import_lib_dynamodb.QueryCommand({
        TableName: this.tableName,
        IndexName: indexName,
        KeyConditionExpression: `${keyName} = :pk`,
        ExpressionAttributeValues: { ":pk": keyValue },
        ScanIndexForward: forward,
        ExclusiveStartKey: startKey
      }));
      items.push(...result.Items ?? []);
      startKey = result.LastEvaluatedKey;
    } while (startKey);
    return items;
  }
  async deleteKeys(keys) {
    const unique = /* @__PURE__ */ new Map();
    for (const key of keys) unique.set(`${key.pk}|${key.sk}`, key);
    const batches = [...unique.values()];
    for (let index = 0; index < batches.length; index += 25) {
      const chunk = batches.slice(index, index + 25);
      if (chunk.length === 1) {
        await this.documents.send(new import_lib_dynamodb.DeleteCommand({
          TableName: this.tableName,
          Key: { pk: chunk[0].pk, sk: chunk[0].sk }
        }));
        continue;
      }
      await this.documents.send(new import_lib_dynamodb.BatchWriteCommand({
        RequestItems: {
          [this.tableName]: chunk.map((key) => ({
            DeleteRequest: { Key: { pk: key.pk, sk: key.sk } }
          }))
        }
      }));
    }
  }
};

// ../shared/src/graph.ts
function assertAcyclic(tasks) {
  const ids = new Set(tasks.map((task) => task.task_id));
  const indegree = /* @__PURE__ */ new Map();
  const outgoing = /* @__PURE__ */ new Map();
  for (const task of tasks) {
    indegree.set(task.task_id, indegree.get(task.task_id) ?? 0);
    outgoing.set(task.task_id, outgoing.get(task.task_id) ?? []);
  }
  for (const task of tasks) {
    for (const dependency of task.dependencies) {
      if (dependency === task.task_id) {
        throw new HttpError(400, "A task cannot depend on itself.");
      }
      if (!ids.has(dependency)) {
        throw new HttpError(400, `Dependency ${dependency} is not a task in this project.`);
      }
      outgoing.get(dependency)?.push(task.task_id);
      indegree.set(task.task_id, (indegree.get(task.task_id) ?? 0) + 1);
    }
  }
  const queue = [...indegree.entries()].filter(([, degree]) => degree === 0).map(([id]) => id);
  let seen = 0;
  while (queue.length > 0) {
    const id = queue.shift();
    if (!id) break;
    seen += 1;
    for (const next of outgoing.get(id) ?? []) {
      const degree = (indegree.get(next) ?? 1) - 1;
      indegree.set(next, degree);
      if (degree === 0) queue.push(next);
    }
  }
  if (seen !== tasks.length) {
    throw new HttpError(400, "Task dependencies contain a cycle.");
  }
}

// ../shared/src/signature.ts
var import_node_crypto2 = require("node:crypto");

// ../shared/src/public-key.ts
var WARPLAN_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA+fyCTeAHtkXGRtYvSI/2TmsDQ8e1trDoCcT1TMtOmRE=
-----END PUBLIC KEY-----
`;

// ../shared/src/signature.ts
var SIGNATURE_VERSION = "v1";
var MAX_SIGNATURE_SKEW_MS = 5 * 60 * 1e3;
function canonicalRequest(method, target, timestamp, rawBody) {
  return `${SIGNATURE_VERSION}
${timestamp}
${method.toUpperCase()}
${target}
${rawBody}`;
}
function requestTarget(event) {
  const path = event.rawPath || "/";
  const query = event.rawQueryString ?? "";
  return query ? `${path}?${query}` : path;
}
function rawRequestBody(event) {
  if (!event.body) return "";
  return event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body;
}
function assertSignedRequest(event, now = Date.now()) {
  const timestamp = header(event, "x-warplan-timestamp");
  const signature = header(event, "x-warplan-signature");
  if (!timestamp || !signature) {
    throw new HttpError(401, "Request signature is required.");
  }
  if (!/^\d+$/.test(timestamp)) {
    throw new HttpError(401, "Request signature is invalid.");
  }
  if (Math.abs(now - Number(timestamp)) > MAX_SIGNATURE_SKEW_MS) {
    throw new HttpError(401, "Request signature has expired.");
  }
  const message = canonicalRequest(
    event.requestContext.http.method,
    requestTarget(event),
    timestamp,
    rawRequestBody(event)
  );
  let valid = false;
  try {
    valid = (0, import_node_crypto2.verify)(null, Buffer.from(message, "utf8"), publicKey(), Buffer.from(signature, "base64"));
  } catch {
    valid = false;
  }
  if (!valid) {
    throw new HttpError(401, "Request signature is invalid.");
  }
}
function header(event, name) {
  const wanted = name.toLowerCase();
  for (const [key, value] of Object.entries(event.headers ?? {})) {
    if (key.toLowerCase() === wanted && typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }
  return void 0;
}
var cachedKey;
function publicKey() {
  cachedKey ??= (0, import_node_crypto2.createPublicKey)(WARPLAN_PUBLIC_KEY);
  return cachedKey;
}

// ../shared/src/http.ts
function jsonBody(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new HttpError(400, "Expected a JSON object.");
  }
  return value;
}
function requireString(body, field) {
  const value = body[field];
  if (typeof value !== "string" || !value.trim()) {
    throw new HttpError(400, `${field} is required.`);
  }
  return value.trim();
}
function optionalString(body, field) {
  const value = body[field];
  if (value == null || value === "") return void 0;
  if (typeof value !== "string") throw new HttpError(400, `${field} must be a string.`);
  return value.trim();
}
function decodeBody(event) {
  if (!event.body) return void 0;
  const raw = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body;
  if (!raw) return void 0;
  try {
    return JSON.parse(raw);
  } catch {
    throw new HttpError(400, "Request body must be JSON.");
  }
}
function matchPath(template, path) {
  const expected = template.split("/").filter(Boolean);
  const actual = path.split("/").filter(Boolean);
  if (expected.length !== actual.length) return null;
  const params = {};
  for (let index = 0; index < expected.length; index += 1) {
    const token = expected[index];
    const value = actual[index];
    if (token.startsWith("{") && token.endsWith("}")) {
      params[token.slice(1, -1)] = decodeURIComponent(value);
    } else if (token !== value) {
      return null;
    }
  }
  return params;
}
function rejectUnsigned(event) {
  try {
    assertSignedRequest(event);
    return void 0;
  } catch (error) {
    if (error instanceof HttpError) return respond(error.status, { error: error.message });
    throw error;
  }
}
async function dispatch(event, routes2) {
  try {
    assertSignedRequest(event);
    const request = {
      method: event.requestContext.http.method.toUpperCase(),
      path: event.rawPath || "/",
      body: decodeBody(event),
      query: Object.fromEntries(
        Object.entries(event.queryStringParameters ?? {}).filter((entry) => typeof entry[1] === "string")
      )
    };
    let found;
    for (const route of routes2) {
      if (route.method !== request.method) continue;
      const params = matchPath(route.path, request.path);
      if (params) {
        found = { route, params };
        break;
      }
    }
    if (!found) {
      return respond(404, { error: `No route for ${request.method} ${request.path}` });
    }
    const result = await found.route.handler(request, found.params);
    return respond(result.statusCode, result.body ?? {});
  } catch (error) {
    if (error instanceof HttpError) {
      return respond(error.status, { error: error.message });
    }
    console.error(error);
    return respond(500, { error: "Internal error" });
  }
}
function respond(statusCode, body) {
  return {
    statusCode,
    headers: {
      "content-type": "application/json",
      "access-control-allow-origin": "*"
    },
    body: JSON.stringify(body)
  };
}

// ../shared/src/runtime.ts
function createDefaultDeps() {
  const tableName = process.env.WARPLAN_TABLE_NAME;
  if (!tableName) {
    throw new Error("WARPLAN_TABLE_NAME is required");
  }
  return {
    repo: new DynamoRepository(tableName),
    cursor: new HttpCursorClient({
      apiKey: process.env.CURSOR_API_KEY ?? "",
      baseUrl: process.env.CURSOR_API_BASE
    })
  };
}

// ../shared/src/task-list.ts
function requiredText(value, label) {
  if (typeof value !== "string" || !value.trim()) {
    throw new HttpError(400, `${label} is required.`);
  }
  return value.trim();
}
function dependsOn(value, label) {
  if (value == null) return [];
  if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) {
    throw new HttpError(400, `${label} must be an array of task titles.`);
  }
  return value.map((item) => item.trim()).filter(Boolean);
}
function outputTypesOf(value, label) {
  const raw = Array.isArray(value) ? value : [value];
  const tokens = raw.flatMap((item) => typeof item === "string" ? item.split(/[+,/]/) : []).map((item) => item.trim().toLowerCase()).filter(Boolean);
  if (tokens.length === 0) {
    throw new HttpError(400, `${label} must be "code" or "research".`);
  }
  const types = /* @__PURE__ */ new Set();
  for (const token of tokens) {
    if (token === "both" || token === "code+research" || token === "research+code") {
      types.add("research");
      types.add("code");
      continue;
    }
    if (token !== "code" && token !== "research") {
      throw new HttpError(400, `${label} must be "code" or "research".`);
    }
    types.add(token);
  }
  return [...types];
}
function normalizeTaskDrafts(raw) {
  if (raw.length === 0) {
    throw new HttpError(400, "The task list is empty.");
  }
  const normalized = [];
  raw.forEach((item, index) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) {
      throw new HttpError(400, `Task ${index + 1} must be an object.`);
    }
    const record = item;
    const title = requiredText(record.title, `Task ${index + 1} title`);
    const prompt = requiredText(record.prompt, `Task ${index + 1} prompt`);
    const depends = dependsOn(record.depends_on ?? record.dependencies, `Task ${index + 1} depends_on`);
    const types = outputTypesOf(record.output_type, `Task ${index + 1} output_type`);
    if (types.length === 1) {
      normalized.push({ title, prompt, output_type: types[0], depends_on: depends });
      return;
    }
    const researchTitle = `${title} (research)`;
    const codeTitle = `${title} (code)`;
    normalized.push({
      title: researchTitle,
      prompt: `${prompt}

Produce only the research output for this task.`,
      output_type: "research",
      depends_on: depends
    });
    normalized.push({
      title: codeTitle,
      prompt: `${prompt}

Produce only the code output for this task, using the companion research task as input.`,
      output_type: "code",
      depends_on: [...depends, researchTitle]
    });
  });
  return normalized;
}

// ../shared/src/tasks-service.ts
var TasksService = class {
  constructor(repo, cursor, clock = systemClock) {
    this.repo = repo;
    this.cursor = cursor;
    this.clock = clock;
  }
  async list(projectId) {
    await this.requireProject(projectId);
    return this.repo.listTasks(projectId);
  }
  async get(projectId, taskId) {
    return this.requireTask(projectId, taskId);
  }
  async createOne(projectId, input) {
    await this.requireProject(projectId);
    const existing = await this.repo.listTasks(projectId);
    const title = input.title?.trim() || "New task";
    const prompt = input.prompt?.trim() || "Describe what this task should do.";
    const outputType2 = input.output_type ?? "code";
    if (!isOutputType(outputType2)) throw new HttpError(400, "output_type must be code or research.");
    const dependencies = input.depends_on ? [input.depends_on] : [];
    if (dependencies.some((id) => !existing.some((task2) => task2.task_id === id))) {
      throw new HttpError(400, "depends_on must be a task in this project.");
    }
    const timestamp = this.clock.nowIso();
    const task = {
      task_id: this.clock.newId(),
      project_id: projectId,
      title,
      prompt,
      dependencies,
      status: "TODO",
      output_type: outputType2,
      order: existing.length,
      created_at: timestamp,
      updated_at: timestamp
    };
    assertAcyclic([...existing, task]);
    await this.repo.saveTask(task);
    return task;
  }
  async createBatch(projectId, drafts) {
    await this.requireProject(projectId);
    const normalized = normalizeTaskDrafts(drafts);
    const existing = await this.repo.listTasks(projectId);
    const timestamp = this.clock.nowIso();
    const created = normalized.map((draft, index) => ({
      task_id: this.clock.newId(),
      project_id: projectId,
      title: draft.title,
      prompt: draft.prompt,
      dependencies: [],
      status: "TODO",
      output_type: draft.output_type,
      order: existing.length + index,
      created_at: timestamp,
      updated_at: timestamp
    }));
    this.bindDependencies(existing, created, normalized);
    assertAcyclic([...existing, ...created]);
    await this.repo.saveTasks(created);
    return created;
  }
  async update(projectId, taskId, patch) {
    const task = await this.requireTask(projectId, taskId);
    if (patch.title !== void 0) {
      const title = patch.title.trim();
      if (!title) throw new HttpError(400, "title is required.");
      task.title = title;
    }
    if (patch.prompt !== void 0) {
      const prompt = patch.prompt.trim();
      if (!prompt) throw new HttpError(400, "prompt is required.");
      task.prompt = prompt;
    }
    if (patch.output_type !== void 0) {
      if (!isOutputType(patch.output_type)) throw new HttpError(400, "output_type must be code or research.");
      if (patch.output_type !== task.output_type) {
        const other = task.output_type === "code" ? await this.repo.getResearchOutput(taskId) : await this.repo.getCodeOutput(taskId);
        if (other) {
          throw new HttpError(400, "Split mixed outputs into two tasks instead of changing output_type.");
        }
      }
      task.output_type = patch.output_type;
    }
    if (patch.dependencies !== void 0) {
      if (!Array.isArray(patch.dependencies) || patch.dependencies.some((item) => typeof item !== "string")) {
        throw new HttpError(400, "dependencies must be an array of task ids.");
      }
      task.dependencies = [...new Set(patch.dependencies)];
      const tasks = (await this.repo.listTasks(projectId)).map((item) => item.task_id === task.task_id ? task : item);
      assertAcyclic(tasks);
    }
    if (patch.status !== void 0) {
      if (!isTaskStatus(patch.status)) throw new HttpError(400, "Unknown task status.");
      await this.applyStatus(task, patch.status, Boolean(patch.manual));
    }
    task.updated_at = this.clock.nowIso();
    await this.repo.saveTask(task);
    return task;
  }
  async transition(projectId, taskId, status, manual) {
    return this.update(projectId, taskId, { status, manual });
  }
  async remove(projectId, taskId) {
    const task = await this.requireTask(projectId, taskId);
    if (task.cursor_agent_id) await this.cursor.archiveAgent(task.cursor_agent_id);
    await this.repo.deleteTask(taskId);
  }
  async reorder(projectId, taskIds) {
    await this.requireProject(projectId);
    const tasks = await this.repo.listTasks(projectId);
    if (taskIds.length !== tasks.length || new Set(taskIds).size !== taskIds.length) {
      throw new HttpError(400, "Reorder must include each task in the project exactly once.");
    }
    const byId = new Map(tasks.map((task) => [task.task_id, task]));
    const timestamp = this.clock.nowIso();
    const ordered = taskIds.map((taskId, order) => {
      const task = byId.get(taskId);
      if (!task) throw new HttpError(400, `Unknown task ${taskId}.`);
      return { ...task, order, updated_at: timestamp };
    });
    await this.repo.saveTasks(ordered);
    return ordered;
  }
  bindDependencies(existing, created, drafts) {
    const titles = /* @__PURE__ */ new Map();
    for (const task of [...existing, ...created]) {
      const ids = titles.get(task.title) ?? [];
      ids.push(task.task_id);
      titles.set(task.title, ids);
    }
    created.forEach((task, index) => {
      task.dependencies = drafts[index].depends_on.map((title) => {
        const matches = titles.get(title) ?? [];
        if (matches.length === 0) throw new HttpError(400, `Unknown dependency "${title}".`);
        if (matches.length > 1) throw new HttpError(400, `Dependency "${title}" matches more than one task.`);
        return matches[0];
      });
    });
  }
  async applyStatus(task, status, manual) {
    assertCanTransition(task.status, status, manual);
    if (status === "DOING" && !task.cursor_agent_id) {
      if (!manual) await this.assertDependenciesDone(task);
      await this.launch(task);
    }
    task.status = status;
    if (status !== "DOING") task.pending_action = void 0;
  }
  async assertDependenciesDone(task) {
    const tasks = await this.repo.listTasks(task.project_id);
    const byId = new Map(tasks.map((item) => [item.task_id, item]));
    for (const dependency of task.dependencies) {
      const other = byId.get(dependency);
      if (!other || other.status !== "DONE") {
        throw new HttpError(409, "Dependencies must be DONE before this task can start.");
      }
    }
  }
  async launch(task) {
    const project = await this.requireProject(task.project_id);
    if (!project.repo_url) {
      throw new HttpError(400, "Add a repository to the project before starting a task.");
    }
    const created = await this.cursor.createAgent({
      prompt: taskExecutionPrompt(task, project),
      name: task.title,
      mode: "agent",
      repoUrl: project.repo_url,
      startingRef: project.starting_ref || "main",
      autoCreatePr: true
    });
    task.cursor_agent_id = created.agent.id;
    task.cursor_chat_link = created.agent.url;
    task.latest_run_id = created.run.id;
    await this.repo.saveMessage({
      message_id: this.clock.newId(),
      scope: "task",
      project_id: task.project_id,
      task_id: task.task_id,
      role: "user",
      content: task.prompt,
      created_at: this.clock.nowIso(),
      run_id: created.run.id,
      intent: "chat"
    });
  }
  async requireProject(projectId) {
    const project = await this.repo.getProject(projectId);
    if (!project) throw new HttpError(404, "Project not found.");
    return project;
  }
  async requireTask(projectId, taskId) {
    const task = await this.repo.getTask(taskId);
    if (!task || task.project_id !== projectId) throw new HttpError(404, "Task not found.");
    return task;
  }
};

// src/handler.ts
function routes(deps) {
  const service = new TasksService(deps.repo, deps.cursor);
  return [
    {
      method: "GET",
      path: "/projects/{projectId}/tasks",
      handler: async (_request, params) => ({
        statusCode: 200,
        body: { tasks: await service.list(params.projectId) }
      })
    },
    {
      method: "POST",
      path: "/projects/{projectId}/tasks",
      handler: async (request, params) => {
        const body = jsonBody(request.body);
        if (body.task && typeof body.task === "object" && !Array.isArray(body.task)) {
          const draft = body.task;
          const task = await service.createOne(params.projectId, {
            title: optionalString(draft, "title"),
            prompt: optionalString(draft, "prompt"),
            output_type: draft.output_type === void 0 ? void 0 : outputType(draft.output_type),
            depends_on: optionalString(draft, "depends_on")
          });
          return { statusCode: 201, body: { task } };
        }
        if (!Array.isArray(body.tasks)) throw new HttpError(400, "tasks must be an array.");
        const tasks = await service.createBatch(params.projectId, body.tasks);
        return { statusCode: 201, body: { tasks } };
      }
    },
    {
      method: "POST",
      path: "/projects/{projectId}/tasks/reorder",
      handler: async (request, params) => {
        const body = jsonBody(request.body);
        if (!Array.isArray(body.task_ids) || body.task_ids.some((id) => typeof id !== "string")) {
          throw new HttpError(400, "task_ids must be an array of strings.");
        }
        return { statusCode: 200, body: { tasks: await service.reorder(params.projectId, body.task_ids) } };
      }
    },
    {
      method: "GET",
      path: "/projects/{projectId}/tasks/{taskId}",
      handler: async (_request, params) => ({
        statusCode: 200,
        body: await service.get(params.projectId, params.taskId)
      })
    },
    {
      method: "PATCH",
      path: "/projects/{projectId}/tasks/{taskId}",
      handler: async (request, params) => {
        const body = jsonBody(request.body);
        const dependencies = body.dependencies;
        return {
          statusCode: 200,
          body: await service.update(params.projectId, params.taskId, {
            title: optionalString(body, "title"),
            prompt: optionalString(body, "prompt"),
            output_type: body.output_type === void 0 ? void 0 : outputType(body.output_type),
            dependencies: dependencies === void 0 ? void 0 : stringArray(dependencies, "dependencies"),
            status: body.status === void 0 ? void 0 : statusOf(body.status),
            manual: body.manual === true
          })
        };
      }
    },
    {
      method: "DELETE",
      path: "/projects/{projectId}/tasks/{taskId}",
      handler: async (_request, params) => {
        await service.remove(params.projectId, params.taskId);
        return { statusCode: 204, body: {} };
      }
    },
    {
      method: "POST",
      path: "/projects/{projectId}/tasks/{taskId}/transition",
      handler: async (request, params) => {
        const body = jsonBody(request.body);
        const task = await service.transition(
          params.projectId,
          params.taskId,
          statusOf(requireString(body, "status")),
          body.manual === true
        );
        return { statusCode: 200, body: task };
      }
    }
  ];
}
function outputType(value) {
  if (!isOutputType(value)) throw new HttpError(400, "output_type must be code or research.");
  return value;
}
function statusOf(value) {
  if (!isTaskStatus(value)) throw new HttpError(400, "Unknown task status.");
  return value;
}
function stringArray(value, field) {
  if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) {
    throw new HttpError(400, `${field} must be an array of strings.`);
  }
  return value;
}
function createHandler(deps) {
  return async (event) => {
    const rejected = rejectUnsigned(event);
    if (rejected) return rejected;
    return dispatch(event, routes(deps));
  };
}
var defaultDeps;
var handler = async (event) => {
  const rejected = rejectUnsigned(event);
  if (rejected) return rejected;
  defaultDeps ??= createDefaultDeps();
  return dispatch(event, routes(defaultDeps));
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createHandler,
  handler
});
