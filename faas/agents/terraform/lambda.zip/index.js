"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/handler.ts
var handler_exports = {};
__export(handler_exports, {
  createHandler: () => createHandler,
  handler: () => handler
});
module.exports = __toCommonJS(handler_exports);

// ../shared/src/errors.ts
var HttpError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
    this.name = "HttpError";
  }
};

// ../shared/src/ids.ts
var import_node_crypto = require("node:crypto");
function newId() {
  return (0, import_node_crypto.randomUUID)();
}
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
var systemClock = { newId, nowIso };

// ../shared/src/agents-service.ts
var AgentsService = class {
  constructor(repo, cursor, clock = systemClock) {
    this.repo = repo;
    this.cursor = cursor;
    this.clock = clock;
  }
  getAgent(agentId) {
    return this.cursor.getAgent(agentId);
  }
  listRuns(agentId) {
    return this.cursor.listRuns(agentId);
  }
  async createRun(agentId, text, mode) {
    const content = text.trim();
    if (!content) throw new HttpError(400, "prompt is required.");
    const run = await this.cursor.createRun(agentId, { text: content, mode });
    const project = await this.repo.findProjectByAgent(agentId);
    const task = project ? null : await this.repo.findTaskByAgent(agentId);
    const timestamp = this.clock.nowIso();
    if (project) {
      project.latest_run_id = run.id;
      project.updated_at = timestamp;
      await this.repo.saveProject(project);
      await this.repo.saveMessage({
        message_id: this.clock.newId(),
        scope: "project",
        project_id: project.project_id,
        role: "user",
        content,
        created_at: timestamp,
        run_id: run.id,
        intent: "chat"
      });
    } else if (task) {
      task.latest_run_id = run.id;
      task.updated_at = timestamp;
      await this.repo.saveTask(task);
      await this.repo.saveMessage({
        message_id: this.clock.newId(),
        scope: "task",
        project_id: task.project_id,
        task_id: task.task_id,
        role: "user",
        content,
        created_at: timestamp,
        run_id: run.id,
        intent: "chat"
      });
    }
    return run;
  }
  cancelRun(agentId, runId) {
    return this.cursor.cancelRun(agentId, runId);
  }
};

// ../shared/src/cursor-client.ts
function asRecord(value) {
  return value && typeof value === "object" ? value : {};
}
function mapAgent(value) {
  const record = asRecord(value);
  return {
    id: String(record.id ?? ""),
    name: String(record.name ?? ""),
    status: String(record.status ?? ""),
    url: String(record.url ?? ""),
    latestRunId: typeof record.latestRunId === "string" ? record.latestRunId : void 0
  };
}
function mapRun(value) {
  const record = asRecord(value);
  const git = asRecord(record.git);
  const branches = Array.isArray(git.branches) ? git.branches.map((item) => {
    const branch = asRecord(item);
    return {
      repoUrl: String(branch.repoUrl ?? ""),
      branch: typeof branch.branch === "string" ? branch.branch : void 0,
      prUrl: typeof branch.prUrl === "string" ? branch.prUrl : void 0
    };
  }) : void 0;
  return {
    id: String(record.id ?? ""),
    agentId: String(record.agentId ?? ""),
    status: String(record.status ?? ""),
    result: typeof record.result === "string" ? record.result : void 0,
    git: branches ? { branches } : void 0
  };
}
var HttpCursorClient = class {
  constructor(options) {
    this.options = options;
    this.baseUrl = (options.baseUrl ?? "https://api.cursor.com").replace(/\/$/, "");
    this.fetchImpl = options.fetchImpl ?? fetch;
  }
  baseUrl;
  fetchImpl;
  async createAgent(input) {
    const body = {
      prompt: { text: input.prompt },
      mode: input.mode ?? "agent",
      autoCreatePR: input.autoCreatePr ?? false
    };
    if (input.name) body.name = input.name.slice(0, 100);
    if (input.repoUrl) {
      const repo = { url: input.repoUrl };
      if (input.startingRef) repo.startingRef = input.startingRef;
      if (input.prUrl) repo.prUrl = input.prUrl;
      body.repos = [repo];
    }
    const payload = await this.request("POST", "/v1/agents", body);
    return { agent: mapAgent(payload.agent), run: mapRun(payload.run) };
  }
  async getAgent(agentId) {
    return mapAgent(await this.request("GET", `/v1/agents/${encodeURIComponent(agentId)}`));
  }
  async archiveAgent(agentId) {
    await this.request("POST", `/v1/agents/${encodeURIComponent(agentId)}/archive`);
  }
  async createRun(agentId, input) {
    const body = { prompt: { text: input.text } };
    if (input.mode) body.mode = input.mode;
    const payload = await this.request(
      "POST",
      `/v1/agents/${encodeURIComponent(agentId)}/runs`,
      body
    );
    return mapRun(payload.run ?? payload);
  }
  async listRuns(agentId) {
    const payload = await this.request(
      "GET",
      `/v1/agents/${encodeURIComponent(agentId)}/runs?limit=20`
    );
    const items = Array.isArray(payload.items) ? payload.items : [];
    return items.map((item) => mapRun(item));
  }
  async getRun(agentId, runId) {
    return mapRun(
      await this.request(
        "GET",
        `/v1/agents/${encodeURIComponent(agentId)}/runs/${encodeURIComponent(runId)}`
      )
    );
  }
  async cancelRun(agentId, runId) {
    await this.request(
      "POST",
      `/v1/agents/${encodeURIComponent(agentId)}/runs/${encodeURIComponent(runId)}/cancel`
    );
  }
  async request(method, path, body) {
    if (!this.options.apiKey) {
      throw new HttpError(500, "CURSOR_API_KEY is not configured.");
    }
    const response = await this.fetchImpl(`${this.baseUrl}${path}`, {
      method,
      headers: {
        authorization: `Basic ${Buffer.from(`${this.options.apiKey}:`).toString("base64")}`,
        accept: "application/json",
        ...body === void 0 ? {} : { "content-type": "application/json" }
      },
      body: body === void 0 ? void 0 : JSON.stringify(body)
    });
    const text = await response.text();
    let parsed = {};
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = { message: text };
      }
    }
    if (!response.ok) {
      const record = asRecord(parsed);
      const message = typeof record.message === "string" && record.message ? record.message : text || response.statusText;
      const status = response.status === 409 ? 409 : 502;
      throw new HttpError(status, `Cursor API error: ${message}`);
    }
    return parsed;
  }
};

// ../shared/src/prompts.ts
var GENERATE_TASKS_INSTRUCTION = [
  "Generate an ordered list of project tasks based on the agreed decisions in this warplan.",
  "Return only a JSON array, with no markdown and no commentary.",
  "Each item must be an object with:",
  '- "title": string, a short task name',
  '- "prompt": string, the instruction the executing agent should follow',
  '- "output_type": "code" or "research"',
  '- "depends_on": array of task titles this task depends on',
  "A task must declare exactly one output type. If work needs both research and code, emit two tasks.",
  "Order the array so each task appears after the tasks it depends on."
].join("\n");

// ../shared/src/dynamo-repository.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var INTERNAL = /* @__PURE__ */ new Set(["pk", "sk", "entity", "gsi1pk", "gsi1sk", "gsi2pk", "gsi2sk"]);
function strip(item) {
  const copy = {};
  for (const [key, value] of Object.entries(item)) {
    if (!INTERNAL.has(key) && value !== void 0) copy[key] = value;
  }
  return copy;
}
var DynamoRepository = class {
  constructor(tableName, client = new import_client_dynamodb.DynamoDBClient({})) {
    this.tableName = tableName;
    this.documents = import_lib_dynamodb.DynamoDBDocumentClient.from(client, {
      marshallOptions: { removeUndefinedValues: true }
    });
  }
  documents;
  async saveProject(project) {
    await this.documents.send(new import_lib_dynamodb.PutCommand({
      TableName: this.tableName,
      Item: {
        ...project,
        pk: `PROJECT#${project.project_id}`,
        sk: "META",
        entity: "project",
        gsi1pk: "PROJECT",
        gsi1sk: `${project.updated_at}#${project.project_id}`,
        ...project.cursor_agent_id ? { gsi2pk: `AGENT#${project.cursor_agent_id}`, gsi2sk: `PROJECT#${project.project_id}` } : {}
      }
    }));
  }
  async getProject(projectId) {
    const result = await this.documents.send(new import_lib_dynamodb.GetCommand({
      TableName: this.tableName,
      Key: { pk: `PROJECT#${projectId}`, sk: "META" }
    }));
    return result.Item ? strip(result.Item) : null;
  }
  async listProjects() {
    const items = await this.queryIndex("gsi1", "gsi1pk", "PROJECT", false);
    return items.map((item) => strip(item));
  }
  async findProjectByAgent(agentId) {
    const items = await this.queryIndex("gsi2", "gsi2pk", `AGENT#${agentId}`, true);
    const item = items.find((candidate) => candidate.entity === "project");
    return item ? strip(item) : null;
  }
  async deleteProject(projectId) {
    const tasks = await this.listTasks(projectId);
    const keys = (await this.queryPartition(`PROJECT#${projectId}`)).map((item) => ({
      pk: item.pk,
      sk: item.sk
    }));
    for (const task of tasks) {
      const taskItems = await this.queryPartition(`TASK#${task.task_id}`);
      keys.push(...taskItems.map((item) => ({ pk: item.pk, sk: item.sk })));
    }
    await this.deleteKeys(keys);
  }
  async saveTask(task) {
    await this.documents.send(new import_lib_dynamodb.PutCommand({
      TableName: this.tableName,
      Item: {
        ...task,
        pk: `PROJECT#${task.project_id}`,
        sk: `TASK#${task.task_id}`,
        entity: "task",
        gsi2pk: `TASK#${task.task_id}`,
        gsi2sk: "META",
        ...task.cursor_agent_id ? { gsi1pk: `AGENT#${task.cursor_agent_id}`, gsi1sk: `TASK#${task.task_id}` } : {}
      }
    }));
  }
  async saveTasks(tasks) {
    for (const task of tasks) {
      await this.saveTask(task);
    }
  }
  async getTask(taskId) {
    const items = await this.queryIndex("gsi2", "gsi2pk", `TASK#${taskId}`, true);
    const item = items.find((candidate) => candidate.entity === "task");
    return item ? strip(item) : null;
  }
  async listTasks(projectId) {
    const items = await this.queryPartition(`PROJECT#${projectId}`, "TASK#");
    return items.map((item) => strip(item)).sort((left, right) => left.order - right.order || left.created_at.localeCompare(right.created_at));
  }
  async findTaskByAgent(agentId) {
    const items = await this.queryIndex("gsi1", "gsi1pk", `AGENT#${agentId}`, true);
    const item = items.find((candidate) => candidate.entity === "task");
    return item ? strip(item) : null;
  }
  async deleteTask(taskId) {
    const task = await this.getTask(taskId);
    if (!task) return;
    const keys = [
      { pk: `PROJECT#${task.project_id}`, sk: `TASK#${taskId}` },
      ...(await this.queryPartition(`TASK#${taskId}`)).map((item) => ({ pk: item.pk, sk: item.sk }))
    ];
    await this.deleteKeys(keys);
    const siblings = await this.listTasks(task.project_id);
    for (const sibling of siblings) {
      if (!sibling.dependencies.includes(taskId)) continue;
      sibling.dependencies = sibling.dependencies.filter((dependency) => dependency !== taskId);
      await this.saveTask(sibling);
    }
  }
  async getCodeOutput(taskId) {
    return this.getOutput(taskId, "OUTPUT#code");
  }
  async saveCodeOutput(output) {
    await this.putOutput(output.task_id, "OUTPUT#code", "task_code_output", output);
  }
  async getResearchOutput(taskId) {
    return this.getOutput(taskId, "OUTPUT#research");
  }
  async saveResearchOutput(output) {
    await this.putOutput(output.task_id, "OUTPUT#research", "task_research_output", output);
  }
  async listProjectMessages(projectId) {
    const items = await this.queryPartition(`PROJECT#${projectId}`, "MSG#");
    return items.map((item) => strip(item));
  }
  async listTaskMessages(taskId) {
    const items = await this.queryPartition(`TASK#${taskId}`, "MSG#");
    return items.map((item) => strip(item));
  }
  async saveMessage(message) {
    const pk = message.scope === "project" ? `PROJECT#${message.project_id}` : `TASK#${message.task_id}`;
    await this.documents.send(new import_lib_dynamodb.PutCommand({
      TableName: this.tableName,
      Item: {
        ...message,
        pk,
        sk: `MSG#${message.created_at}#${message.message_id}`,
        entity: "message"
      }
    }));
  }
  async getOutput(taskId, sk) {
    const result = await this.documents.send(new import_lib_dynamodb.GetCommand({
      TableName: this.tableName,
      Key: { pk: `TASK#${taskId}`, sk }
    }));
    return result.Item ? strip(result.Item) : null;
  }
  async putOutput(taskId, sk, entity, output) {
    await this.documents.send(new import_lib_dynamodb.PutCommand({
      TableName: this.tableName,
      Item: { ...output, pk: `TASK#${taskId}`, sk, entity }
    }));
  }
  async queryPartition(pk, skPrefix) {
    const items = [];
    let startKey;
    do {
      const result = await this.documents.send(new import_lib_dynamodb.QueryCommand({
        TableName: this.tableName,
        KeyConditionExpression: skPrefix ? "pk = :pk AND begins_with(sk, :sk)" : "pk = :pk",
        ExpressionAttributeValues: skPrefix ? { ":pk": pk, ":sk": skPrefix } : { ":pk": pk },
        ExclusiveStartKey: startKey
      }));
      items.push(...result.Items ?? []);
      startKey = result.LastEvaluatedKey;
    } while (startKey);
    return items;
  }
  async queryIndex(indexName, keyName, keyValue, forward) {
    const items = [];
    let startKey;
    do {
      const result = await this.documents.send(new import_lib_dynamodb.QueryCommand({
        TableName: this.tableName,
        IndexName: indexName,
        KeyConditionExpression: `${keyName} = :pk`,
        ExpressionAttributeValues: { ":pk": keyValue },
        ScanIndexForward: forward,
        ExclusiveStartKey: startKey
      }));
      items.push(...result.Items ?? []);
      startKey = result.LastEvaluatedKey;
    } while (startKey);
    return items;
  }
  async deleteKeys(keys) {
    const unique = /* @__PURE__ */ new Map();
    for (const key of keys) unique.set(`${key.pk}|${key.sk}`, key);
    const batches = [...unique.values()];
    for (let index = 0; index < batches.length; index += 25) {
      const chunk = batches.slice(index, index + 25);
      if (chunk.length === 1) {
        await this.documents.send(new import_lib_dynamodb.DeleteCommand({
          TableName: this.tableName,
          Key: { pk: chunk[0].pk, sk: chunk[0].sk }
        }));
        continue;
      }
      await this.documents.send(new import_lib_dynamodb.BatchWriteCommand({
        RequestItems: {
          [this.tableName]: chunk.map((key) => ({
            DeleteRequest: { Key: { pk: key.pk, sk: key.sk } }
          }))
        }
      }));
    }
  }
};

// ../shared/src/signature.ts
var import_node_crypto2 = require("node:crypto");

// ../shared/src/public-key.ts
var WARPLAN_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA+fyCTeAHtkXGRtYvSI/2TmsDQ8e1trDoCcT1TMtOmRE=
-----END PUBLIC KEY-----
`;

// ../shared/src/signature.ts
var SIGNATURE_VERSION = "v1";
var MAX_SIGNATURE_SKEW_MS = 5 * 60 * 1e3;
function canonicalRequest(method, target, timestamp, rawBody) {
  return `${SIGNATURE_VERSION}
${timestamp}
${method.toUpperCase()}
${target}
${rawBody}`;
}
function requestTarget(event) {
  const path = event.rawPath || "/";
  const query = event.rawQueryString ?? "";
  return query ? `${path}?${query}` : path;
}
function rawRequestBody(event) {
  if (!event.body) return "";
  return event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body;
}
function assertSignedRequest(event, now = Date.now()) {
  const timestamp = header(event, "x-warplan-timestamp");
  const signature = header(event, "x-warplan-signature");
  if (!timestamp || !signature) {
    throw new HttpError(401, "Request signature is required.");
  }
  if (!/^\d+$/.test(timestamp)) {
    throw new HttpError(401, "Request signature is invalid.");
  }
  if (Math.abs(now - Number(timestamp)) > MAX_SIGNATURE_SKEW_MS) {
    throw new HttpError(401, "Request signature has expired.");
  }
  const message = canonicalRequest(
    event.requestContext.http.method,
    requestTarget(event),
    timestamp,
    rawRequestBody(event)
  );
  let valid = false;
  try {
    valid = (0, import_node_crypto2.verify)(null, Buffer.from(message, "utf8"), publicKey(), Buffer.from(signature, "base64"));
  } catch {
    valid = false;
  }
  if (!valid) {
    throw new HttpError(401, "Request signature is invalid.");
  }
}
function header(event, name) {
  const wanted = name.toLowerCase();
  for (const [key, value] of Object.entries(event.headers ?? {})) {
    if (key.toLowerCase() === wanted && typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }
  return void 0;
}
var cachedKey;
function publicKey() {
  cachedKey ??= (0, import_node_crypto2.createPublicKey)(WARPLAN_PUBLIC_KEY);
  return cachedKey;
}

// ../shared/src/http.ts
function jsonBody(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new HttpError(400, "Expected a JSON object.");
  }
  return value;
}
function requireString(body, field) {
  const value = body[field];
  if (typeof value !== "string" || !value.trim()) {
    throw new HttpError(400, `${field} is required.`);
  }
  return value.trim();
}
function optionalString(body, field) {
  const value = body[field];
  if (value == null || value === "") return void 0;
  if (typeof value !== "string") throw new HttpError(400, `${field} must be a string.`);
  return value.trim();
}
function decodeBody(event) {
  if (!event.body) return void 0;
  const raw = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body;
  if (!raw) return void 0;
  try {
    return JSON.parse(raw);
  } catch {
    throw new HttpError(400, "Request body must be JSON.");
  }
}
function matchPath(template, path) {
  const expected = template.split("/").filter(Boolean);
  const actual = path.split("/").filter(Boolean);
  if (expected.length !== actual.length) return null;
  const params = {};
  for (let index = 0; index < expected.length; index += 1) {
    const token = expected[index];
    const value = actual[index];
    if (token.startsWith("{") && token.endsWith("}")) {
      params[token.slice(1, -1)] = decodeURIComponent(value);
    } else if (token !== value) {
      return null;
    }
  }
  return params;
}
function rejectUnsigned(event) {
  try {
    assertSignedRequest(event);
    return void 0;
  } catch (error) {
    if (error instanceof HttpError) return respond(error.status, { error: error.message });
    throw error;
  }
}
async function dispatch(event, routes2) {
  try {
    assertSignedRequest(event);
    const request = {
      method: event.requestContext.http.method.toUpperCase(),
      path: event.rawPath || "/",
      body: decodeBody(event),
      query: Object.fromEntries(
        Object.entries(event.queryStringParameters ?? {}).filter((entry) => typeof entry[1] === "string")
      )
    };
    let found;
    for (const route of routes2) {
      if (route.method !== request.method) continue;
      const params = matchPath(route.path, request.path);
      if (params) {
        found = { route, params };
        break;
      }
    }
    if (!found) {
      return respond(404, { error: `No route for ${request.method} ${request.path}` });
    }
    const result = await found.route.handler(request, found.params);
    return respond(result.statusCode, result.body ?? {});
  } catch (error) {
    if (error instanceof HttpError) {
      return respond(error.status, { error: error.message });
    }
    console.error(error);
    return respond(500, { error: "Internal error" });
  }
}
function respond(statusCode, body) {
  return {
    statusCode,
    headers: {
      "content-type": "application/json",
      "access-control-allow-origin": "*"
    },
    body: JSON.stringify(body)
  };
}

// ../shared/src/runtime.ts
function createDefaultDeps() {
  const tableName = process.env.WARPLAN_TABLE_NAME;
  if (!tableName) {
    throw new Error("WARPLAN_TABLE_NAME is required");
  }
  return {
    repo: new DynamoRepository(tableName),
    cursor: new HttpCursorClient({
      apiKey: process.env.CURSOR_API_KEY ?? "",
      baseUrl: process.env.CURSOR_API_BASE
    })
  };
}

// src/handler.ts
function routes(deps) {
  const service = new AgentsService(deps.repo, deps.cursor);
  return [
    {
      method: "GET",
      path: "/agents/{agentId}",
      handler: async (_request, params) => ({ statusCode: 200, body: await service.getAgent(params.agentId) })
    },
    {
      method: "GET",
      path: "/agents/{agentId}/runs",
      handler: async (_request, params) => ({
        statusCode: 200,
        body: { runs: await service.listRuns(params.agentId) }
      })
    },
    {
      method: "POST",
      path: "/agents/{agentId}/runs",
      handler: async (request, params) => {
        const body = jsonBody(request.body);
        const mode = optionalString(body, "mode");
        if (mode !== void 0 && mode !== "agent" && mode !== "plan") {
          throw new HttpError(400, "mode must be agent or plan.");
        }
        const run = await service.createRun(params.agentId, requireString(body, "prompt"), mode);
        return { statusCode: 202, body: run };
      }
    },
    {
      method: "POST",
      path: "/agents/{agentId}/runs/{runId}/cancel",
      handler: async (_request, params) => {
        await service.cancelRun(params.agentId, params.runId);
        return { statusCode: 200, body: { id: params.runId } };
      }
    }
  ];
}
function createHandler(deps) {
  return async (event) => {
    const rejected = rejectUnsigned(event);
    if (rejected) return rejected;
    return dispatch(event, routes(deps));
  };
}
var defaultDeps;
var handler = async (event) => {
  const rejected = rejectUnsigned(event);
  if (rejected) return rejected;
  defaultDeps ??= createDefaultDeps();
  return dispatch(event, routes(defaultDeps));
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createHandler,
  handler
});
